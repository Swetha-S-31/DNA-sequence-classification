from flask import Flask, render_template, request
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import pandas as pd

app = Flask(__name__)

# Dataset provided in the assignment
DATA = [
    {"id": "S1", "sequence": "ATGCGATC", "group": "A"},
    {"id": "S2", "sequence": "ATGCGTAC", "group": "A"},
    {"id": "S3", "sequence": "GCGCGTAT", "group": "B"},
    {"id": "S4", "sequence": "GCGCGCGC", "group": "B"},
]

def extract_features(sequence):
    """Convert a DNA string into the six numerical features in the assignment."""
    sequence = sequence.strip().upper()
    length = len(sequence)
    counts = {base: sequence.count(base) for base in "ATGC"}
    gc_content = ((counts["G"] + counts["C"]) / length * 100) if length else 0
    return {
        "A": counts["A"],
        "T": counts["T"],
        "G": counts["G"],
        "C": counts["C"],
        "Length": length,
        "GC content (%)": round(gc_content, 2),
    }

def feature_vector(features):
    return [
        features["A"], features["T"], features["G"], features["C"],
        features["Length"], features["GC content (%)"]
    ]

def build_model():
    rows = []
    labels = []
    for item in DATA:
        features = extract_features(item["sequence"])
        rows.append(feature_vector(features))
        labels.append(item["group"])

    model = DecisionTreeClassifier(random_state=42, max_depth=3)
    model.fit(rows, labels)
    training_predictions = model.predict(rows)
    training_accuracy = accuracy_score(labels, training_predictions) * 100
    return model, training_accuracy

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None
    sequence = "ATGCGCGATC"

    model, accuracy = build_model()

    if request.method == "POST":
        sequence = request.form.get("sequence", "").strip().upper()
        if not sequence:
            error = "Please enter a DNA sequence."
        elif any(base not in "ATGC" for base in sequence):
            error = "Invalid sequence. Use only A, T, G and C letters."
        else:
            features = extract_features(sequence)
            prediction = model.predict([feature_vector(features)])[0]
            probabilities = model.predict_proba([feature_vector(features)])[0]
            confidence = float(max(probabilities) * 100)

            result = {
                "sequence": sequence,
                "features": features,
                "prediction": prediction,
                "confidence": round(confidence, 1),
                "accuracy": round(accuracy, 1),
            }

    feature_table = []
    for item in DATA:
        feature_table.append({
            **item,
            "features": extract_features(item["sequence"])
        })

    return render_template(
        "index.html",
        result=result,
        error=error,
        sequence=sequence,
        feature_table=feature_table,
        accuracy=round(accuracy, 1),
    )

if __name__ == "__main__":
    app.run(debug=True)
