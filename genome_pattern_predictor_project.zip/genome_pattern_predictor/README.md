# Genome Pattern Predictor

A small Flask web application for the Introduction to Computational Biology assignment.
It extracts A/T/G/C counts, sequence length and GC percentage, trains a scikit-learn
Decision Tree classifier on the four labelled assignment sequences, and predicts a
group for a new DNA sequence.

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

## Assignment dataset

- S1: ATGCGATC -> A
- S2: ATGCGTAC -> A
- S3: GCGCGTAT -> B
- S4: GCGCGCGC -> B

Default unknown sequence: ATGCGCGATC.

## Important interpretation note

The app displays training-set accuracy, calculated on the same four examples used to fit
the model. With only four examples, this is not a reliable estimate of performance on
unseen biological sequences. The displayed probability is the classifier's class
probability, not a calibrated biological certainty.

This is an educational demonstration, not a clinical or research-grade genomic tool.
